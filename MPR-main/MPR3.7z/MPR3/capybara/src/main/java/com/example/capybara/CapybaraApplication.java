package com.example.capybara;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CapybaraApplication {

	public static void main(String[] args) {

		SpringApplication.run(CapybaraApplication.class, args);
	}
}
