package com.example.capybara;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapybaraApplicationTests {

	@Test
	void contextLoads() {
	}

}
